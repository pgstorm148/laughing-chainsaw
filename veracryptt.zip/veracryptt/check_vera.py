from tkinter import *
import os

#import tc_detect
from tkinter.filedialog import askopenfilename
Tk().withdraw() # we don't want a full GUI, so keep the root window from appearing
filename = askopenfilename() # show an "Open" dialog box and return the path to the selected file
print(filename)
os.system("tc_detect.py " + filename)
tc_detect.tc_detect(filename)
input("Press enter to exit ;)")


# successed loop below


# Tk().withdraw()
# try:
# 	while True:
# 		# we don't want a full GUI, so keep the root window from appearing
# 		filename = askopenfilename() # show an "Open" dialog box and return the path to the selected file
# 		os.system("tc_detect.py " + filename)
# 		#print(filename)
# except KeyboardInterrupt:
# 	print("Press Ctrl-C to terminate while statement")
# 	pass