

import sys
import math
import os
import csv

# This function calcuates the Shanon Entropy
def entropy(string):
  prob = [ float(string.count(c)) / len(string) for c in dict.fromkeys(list(string)) ]
  entropy = - sum([ p * math.log(p) / math.log(2.0) for p in prob ])
  return entropy

# This function reads the signature.csv file
def readsignatures(filename):	
  ifile = open(filename, "r")
  reader = csv.reader(ifile, delimiter=",")
  rownum = 0	
  signatures = []

  for row in reader:
    signatures.append (row)
    rownum += 1

  ifile.close()
  return signatures

# Main script
# Division test
size = os.path.getsize(sys.argv[1])						# Get the file size
if (size % 512 == 0):								# Check if the size is a multiple of 512
  size = "Passed ("+str(size % 512)+")"						# If the file is a multiple, it passed the division test
else:	
  size = "Failed ("+str(size % 512)+")"						# If the file is not a multiple, it failed the test

# Entropy test
in_file		=	open(sys.argv[1], 'rb')					# Get the file to inspect from the command line
chunk_size 	= 	2048							# Set the chunk size to analyze
data 		= 	in_file.read(chunk_size)				# Read the defined chunk size from the file
entropytest = entropy(data)							# Do the entropy test on test chunk
if entropytest > 7.9:								# Check if the entropy is higher than 7.9
  entropytest = "Passed ("+str(entropytest)+")"					# If it is, it passed the test
else:
  entropytest = "Failed ("+str(entropytest)+")"					# If it isn't it failed the test

# File signature test
signatures = readsignatures("signatures.csv")					# Read the signature file
file = open(sys.argv[1], "rb").read(32)						# Read the first 32 bytes of the file
header = " ".join(['{:02X}'.format(byte) for byte in file])			# Convert the bytes into readable hex
detected = ""									# Set the detected variable to ""
for i in range(len(signatures)):						# Loop through the signatures
  if signatures[i][1] in header: 						# Check if the signature appears in the header (first 32 bytes)
    if (detected == ""):							# Check if it's the first match
      detected = signatures[i][0]						# Set detected to the matched file exension
    else:
      detected += ','+signatures[i][0]						# Add the matched file exension to detected

if (detected == ""):								# Check if detected is still ""
  detected = "Passed (unknown format)"						# If it's still empty it passed the test
else:
  detected = "Failed (%s)" % detected						# If it isn't, it failed the test

# Print results
# print ("================================")
# print ("TC/VC Quicktest")
# print ("================================")
# print ("file: %s" % sys.argv[1])
# print ("")
print ("result :")
# print ("")
# print ("Header check:\t%s" % detected)
# print ("Division check:\t%s" % size)
# print ("Entropy test:\t%s" % entropytest)
if "Passed" in detected and "Passed" in size and "Passed" in entropytest:
  print ("Verified")
else :
  print("Verification failed")
input("Press enter to exit")